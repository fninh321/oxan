#!/bin/sh
./logo --algo cuckatoo32 --server europe.pool.easygrin.org:3001 --user grin135aqjadukvgq2tcjy08ast930g0r0jrvrsvrqgygcazsu85wm0eq6e8zc4
